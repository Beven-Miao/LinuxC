/*
 * countryReport.h
 *
 *  Created on: May 4, 2016
 *      Author: codac-dev
 */

#ifndef COUNTRYREPORT_H_
#define COUNTRYREPORT_H_

#include <string>
#include <vector>
#include <map>

struct CountryStat
{
	CountryStat(): average(0.0){};

	std::string code;
	std::string country;
	std::string subchapter;
	std::string title;
	std::string unit;
	double average;
};

class CountryParser
{
public:
	typedef std::vector<CountryStat>::iterator Iterator;

	void parser();

private:

	CountryStat _countryState;
};


#endif /* COUNTRYREPORT_H_ */
