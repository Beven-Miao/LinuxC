/*
 * main.cpp
 *
 *  Created on: May 2, 2016
 *      Author: codac-dev
 */
#include <cstdlib>
#include <ctime>
#include <exception>
#include <iostream>
#include <string>
#include "../include/board.h"
#include "../include/game.h"
#include "../include/gameManager.h"

int main()
{
    std::cout << "Game start! type help for instructions" << std::endl;
    GameManager gameManager;
    std::string operate;
    while(1)
    {
    	std::cin >> operate;

    	if(operate == "help")
    	{
    		std::cout << HELP << std::endl;
    	}
    	else if(operate == "rename")
    	{
    		gameManager.rename();
    	}
    	else if(operate == "new")
    	{
    		gameManager.createGame();
    	}
    	else if(operate == "reset")
    	{
    		gameManager.resetGame();
    	}
    	else if(operate == "switch")
    	{
    		gameManager.switchGame();
    	}
    	else
    	{
    		gameManager.playGame(operate);
    	}
    }

    return 0;
}


