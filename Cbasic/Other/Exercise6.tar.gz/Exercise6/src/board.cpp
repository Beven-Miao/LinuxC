/*
 * board.cpp
 *
 *  Created on: May 2, 2016
 *      Author: codac-dev
 */
#include <iostream>
#include "../include/board.h"

Board::Board()
{
	_boardSize = 0;
}

Board::Board(int boardSize)
{
	_boardSize = boardSize;
	for (int i = 0; i < _boardSize; i++)
	{
		for (int j = 0; j < _boardSize; j++)
		{
			_board[i][j] = EMPTY;
		}
	}
}

void Board::setState(int row, int col, char state)
{
	_board[row][col] = state;
}

void Board::displayBoard()
{
	for (int i = 0; i < _boardSize; i++)
	{
		for (int j = 0; j < _boardSize; j++)
		{
			std::cout << _board[i][j];
		}
		std::cout << std::endl;
	}
}

int Board::getSize()
{
	return _boardSize;
}

char Board::getState(int row, int col)
{
	return _board[row][col];
}

