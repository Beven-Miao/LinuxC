/*
 * boardGame.cpp
 *
 *  Created on: Apr 29, 2016
 *      Author: codac-dev
 */
#include <cstdlib>
#include <ctime>
#include <exception>
#include <iostream>
#include <string>
#include "../include/board.h"
#include "../include/game.h"
#include "../include/gameManager.h"

	GameManager::GameManager()
	{
		gameSum = 0;
		gameId = 0;
		createGame();
	}

    Game* GameManager::createGame()
    {
    	int boardSize;
    	std::cout << "Please input the size of the board" << std::endl;
    	std::cin >> boardSize;
    	Game* game = new Game(boardSize, gameSum);
    	gameSum ++;
    	games[gameSum-1] = game;
    	return this->gameUsing =  game;
    }

    std::string GameManager::rename()
    {
    	Game* game = chooseGame();
    	std::cout << "Please enter the new name!" << std::endl;
    	std::string name;
    	std::cin >> name;
    	game->setName(name);
    	return game->getName();
    }

    Game* GameManager::switchGame()
    {
//    	std::cout << "Plese enter the game you want to play" << std::endl;
        return this->gameUsing = chooseGame();
    }

    Game* GameManager::resetGame()
    {
    	Game* _game = gameUsing;
    	_game->initBoard();
    	return _game;
    }
    Game* GameManager::chooseGame()
    {
    	Game * game = NULL;
    	std::cout << "Using name:" << gameUsing->getName() << std::endl;
    	std::cout << "Please enter the game name" << std::endl;
    	std::string name;
    	while(game == NULL)
    	{
        	std::cin >> name;
        	int gameId = gameSum;
        	while(gameId)
        	{
        		if(name == games[--gameId]->getName())
        		{
        			//TODO should display the using board.
        			game->displayBoard();
        			return game = games[gameId];
        		}
        	}
    	}
    	return NULL;
    }

    void GameManager::playGame(std::string direction)
    {
    	Game* game = this->gameUsing;
    	char c = direction.at(0);
    	try
    	{
    		switch(c)
			{
			case 'u':
				game->moveUp();
				break;
			case 'd':
				game->moveDown();
				break;
			case 'r':
				game->moveRight();
				break;
			case 'l':
				game->moveLeft();
				break;
			}
    	}
    	catch(outrange_exception &)
    	{
    		std::cout << "Invalid move, try again!" << std::endl;
    	}
    	catch(wallhit_expectiom &)
    	{
    		std::cout << "Hit the wall, game over!" << std::endl;
    	}
    	catch(exitreach_exception &)
    	{
    		std::cout << "Arrived the Exit, WIN!" << std::endl;
    	}

    }


