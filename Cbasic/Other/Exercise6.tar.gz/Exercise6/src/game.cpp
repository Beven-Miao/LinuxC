/*
 * game.cpp
 *
 *  Created on: May 2, 2016
 *      Author: codac-dev
 */

#include <iostream>
#include <string>
#include <ctime>
#include <cstdlib>
#include "../include/board.h"
#include "../include/game.h"


	Game::Game(int boardSize,int id)
    {
		_row = 0;
		_col = 0;
		_gameName = "game";
		_board = Board(boardSize);
		initBoard();
	}

	void Game::initBoard()
	{
    	int boardSize = this->_board.getSize();
	 	  for(int i = 0; i < boardSize; i++)
	 	  {
	 		  for(int j = 0; j < boardSize; j++)
	 		  {
	 			  _board.setState(i, j, _board.EMPTY);
	 		  }
	 	  }

		_board.setState(0,0,_board.PLAYER);
		_board.setState(boardSize-1,boardSize-1,_board.EXIT);
		int wallNum = 6;
		srand( time(NULL) );
		while(wallNum)
		{
			int rowRand = rand() % boardSize;
			int colRand = rand() % boardSize;

			if(_board.getState(rowRand, colRand) == _board.EMPTY)
			{
				_board.setState(rowRand, colRand, _board.WALL);
				wallNum--;
			}
		}
		displayBoard();
		_row = 0;
		_col = 0;
	}

	void Game::displayBoard()
	{
		_board.displayBoard();
	}

	void Game::move(int row, int col)
	{
		if(_board.getState(row, col) == _board.EXIT)
		{
			throw exitreach_exception();
		}
		else if(_board.getState(row, col) == _board.WALL)
		{
			throw wallhit_expectiom();
		}
		else if(_board.getState(row, col) == _board.EMPTY)
		{
			_board.setState(row, col, _board.PLAYER);
			_board.setState(_row, _col, _board.EMPTY);
			_row = row;
			_col = col;
		}
		else
		{

			throw outrange_exception();
		}

		displayBoard();
	}

	std::string Game::getName()
	{
		return this->_gameName;
	}

	std::string Game::setName(std::string name)
	{
		return this->_gameName = name;
	}

	void Game::moveUp()
	{
        move(_row-1, _col);
	}

	void Game::moveDown()
	{
		move(_row+1, _col);
	}

	void Game::moveRight()
	{
		move(_row, _col+1);
	}

	void Game::moveLeft()
	{
		move(_row, _col-1);
	}



