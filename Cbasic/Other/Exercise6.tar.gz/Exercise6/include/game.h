/*
 * game.h
 *
 *  Created on: May 2, 2016
 *      Author: codac-dev
 */

#ifndef GAME_H_
#define GAME_H_

class wallhit_expectiom: public std::exception{};

class exitreach_exception: public std::exception{};

class outrange_exception: public std::exception{};

class Game
{

public:
	int _row;
	int _col;
	Board _board;
	std::string _gameName;

//	Game();
	Game(int ,int );

	void initBoard();

	void displayBoard();

	std::string getName();

	std::string setName(std::string name);

	void move(int row, int col);

	void moveUp();

	void moveDown();

	void moveRight();

	void moveLeft();
};


#endif /* GAME_H_ */
