/**
 * board.h
 *
 *  Created on: May 2, 2016
 *      Author: codac-dev
 */
#ifndef BOARD_H_
#define BOARD_H_

class Board {
private:
	int _boardSize;
	char _board[15][15];

public:
	Board();

	Board(int boardSize);

	/**
	 *enum state present the type of the board point.
	 */
	enum state {
		PLAYER = 'P', //!< Location of the Player
		EXIT = 'X', //!< Location of the Exit
		WALL = 'W', //!< Location of the Wall
		EMPTY = '.' //!< Present the path that player can walk through
	};

	void setState(int, int, char);

	void displayBoard();

	int getSize();

	char getState(int, int);

};

#endif /* BOARD_H_ */
