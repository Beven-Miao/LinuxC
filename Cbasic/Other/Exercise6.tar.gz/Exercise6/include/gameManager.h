/*
 * gameManager.h
 *
 *  Created on: May 2, 2016
 *      Author: codac-dev
 */

#ifndef GAMEMANAGER_H_
#define GAMEMANAGER_H_

#define HELP "help: display instrucions\nrename: change the game name\nnew: create a new game\nreset: reset the game\n"

class GameManager
{

	int gameSum;
	int gameId;
	Game* gameUsing;
	Game* games[5];
public:
	GameManager();

    Game* createGame();

    std::string rename();

    Game* switchGame();

    Game* resetGame();

    Game* chooseGame();

    void playGame(std::string );
};



#endif /* GAMEMANAGER_H_ */
